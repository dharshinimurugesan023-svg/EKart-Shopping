<?xml version="1.0" encoding="UTF-8" ?>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:f="http://java.sun.com/jsf/core" xmlns:h="http://java.sun.com/jsf/html">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Insert title here</title>
</head>
<body>
<jsp:include page="/common/header.jsp"></jsp:include>
<c:if test="${not empty products}">
        <table border="1" cellpadding="6">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
            </tr>
            <c:forEach items="${products}" var="product">
                <tr>
                    <td><c:out value="${product.id}" /></td>
                    <td><c:out value="${product.name}" /></td>
                    <td><c:out value="${product.category}" /></td>
                    <td><c:out value="${product.price}" /></td>
                    <td><c:out value="${product.stock}" /></td>
                    <td>
                       <form action="<c:url value='/add-to-cart' />" method="post">
                           <input type="hidden" name="productId" value="${product.id}" />
                           <input type="submit" value="Add to Cart" />
                       </form>
                   </td>

                    
                </tr>
            </c:forEach>
        </table>
    </c:if>

</body>
</html>