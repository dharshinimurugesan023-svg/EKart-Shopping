<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="/common/header.jsp" />
   <h1>Create Your Account</h1>
   <c:if test="${not empty error}">
       <p style="color: red;"><c:out value="${error}" /></p>
   </c:if>
   <form action="<c:url value='/register' />" method="post">
       <p>Name: <input type="text" name="name" value="" required /></p>
       <p>Username: <input type="text" name="username" value="" required /></p>
       <p>Password: <input type="password" name="password" required /></p>
       <p><input type="submit" value="Register" /></p>
   </form>

</body>
</html>