<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
     <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="/common/header.jsp"></jsp:include>
<h1>Checkout</h1>
   <c:if test="${not empty error}">
       <p style="color: red;"><c:out value="${error}" /></p>
   </c:if>
   <c:choose>
       <c:when test="${empty cart.items}">
           <p>Your cart is empty. <a href="<c:url value='/products' />">Continue shopping</a></p>
       </c:when>
       <c:otherwise>
           <table border="1" cellpadding="6">
               <tr>
                   <th>Name</th>
                   <th>Price</th>
                   <th>Quantity</th>
                   <th>Subtotal</th>
               </tr>
               <c:forEach items="${cart.items}" var="item">
                   <tr>
                       <td><c:out value="${item.product.name}" /></td>
                       <td><c:out value="${item.product.price}" /></td>
                       <td><c:out value="${item.quantity}" /></td>
                       <td><c:out value="${item.subtotal}" /></td>
                   </tr>
               </c:forEach>
           </table>
           <h3>Total: <c:out value="${cart.totalPrice}" /></h3>
           <form action="<c:url value='/checkout' />" method="post">
               <input type="submit" value="Place Order" />
           </form>
       </c:otherwise>
   </c:choose>


</body>
</html>