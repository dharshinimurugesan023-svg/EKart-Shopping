<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
   com.ekart.model.Cart sessionCart = null;
   if (session != null) {
       sessionCart = (com.ekart.model.Cart) session.getAttribute("cart");
   }
   int cartCount = (sessionCart != null) ? sessionCart.getTotalQuantity() : 0;
   com.ekart.model.User sessionUser = null;
   if (session != null) {
       sessionUser = (com.ekart.model.User) session.getAttribute("loggedInUser");
   }

%>
<div style="border-bottom: 2px solid #ccc; padding: 10px; margin-bottom: 10px;">
   <strong>EKart</strong>
   &nbsp;|&nbsp;
   <a href="<c:url value='/products' />">Products</a>
   &nbsp;|&nbsp;
   <a href="<c:url value='/cart' />">Cart (<%= cartCount %>)</a>
   	&nbsp;|&nbsp;
   <% if (sessionUser != null) { %>
       <span>Hello, <%= sessionUser.getName() %> (<%= sessionUser.getRole() %>)</span>
       &nbsp;|&nbsp;
       <a href="<c:url value='/logout' />">Logout</a>
       <% if ("ADMIN".equals(sessionUser.getRole())) { %>
           &nbsp;|&nbsp;
           <a href="<c:url value='/admin' />">Admin</a>
       <% } %>
   <% } else { %>
       <a href="<c:url value='/login' />">Login</a>
       &nbsp;|&nbsp;
       <a href="<c:url value='/register' />">Register</a>
   <% } %>
   	
   
</div>
