<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%!
   private String formatPrice(double amount) {
       return String.format("Rs. %.2f", amount);
   }
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="/common/header.jsp"></jsp:include>
<c:choose>
       <c:when test="${empty cart.items}">
           <p>Your cart is empty.</p>
       </c:when>
       <c:otherwise>
           <table border="1" cellpadding="6">
               <tr>
                   <th>Name</th>
                   <th>Price</th>
                   <th>Quantity</th>
                   <th>Subtotal</th>
                   <th></th>
               </tr>
               <%
                   com.ekart.model.Cart cart = (com.ekart.model.Cart) request.getAttribute("cart");
                   for (com.ekart.model.CartItem item : cart.getItems()) {
               %>
                   <tr>
                       <td><%= item.getProduct().getName() %></td>
                       <td><%= formatPrice(item.getProduct().getPrice()) %></td>
                       <td><%= item.getQuantity() %></td>
                       <td><%= formatPrice(item.getSubtotal()) %></td>
                       <td>
                           <form action="<c:url value='/remove-from-cart' />" method="post">
                               <input type="hidden" name="productId" value="<%= item.getProduct().getId() %>" />
                               <input type="submit" value="Remove" />
                           </form>
                       </td>
                   </tr>
               <% } %>
           </table>
           <h3>Total: <%= formatPrice(cart.getTotalPrice()) %></h3>
           <p>
               <a href="<c:url value='/checkout' />">Proceed to Checkout</a>
           </p>
           
       </c:otherwise>
   </c:choose>
<p><a href="<c:url value='/products' />">Continue Shopping</a></p>



</body>
</html>