<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="/common/header.jsp"></jsp:include>
<h1>Order Confirmed!</h1>
   <c:choose>
       <c:when test="${empty order}">
           <p>No recent order found.</p>
       </c:when>
       <c:otherwise>
           <p>Thank you, <c:out value="${order.user.name}" />. Your order has been placed.</p>
           <table border="1" cellpadding="6">
               <tr>
                   <th>Name</th>
                   <th>Price</th>
                   <th>Quantity</th>
                   <th>Subtotal</th>
               </tr>
               <c:forEach items="${order.items}" var="item">
                   <tr>
                       <td><c:out value="${item.product.name}" /></td>
                       <td><c:out value="${item.product.price}" /></td>
                       <td><c:out value="${item.quantity}" /></td>
                       <td><c:out value="${item.subtotal}" /></td>
                   </tr>
               </c:forEach>
           </table>
           <h3>Order Total: <c:out value="${order.total}" /></h3>
       </c:otherwise>
   </c:choose>
   <p><a href="<c:url value='/products' />">Continue Shopping</a></p>



</body>
</html>