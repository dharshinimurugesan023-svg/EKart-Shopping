<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="/common/header.jsp"></jsp:include>
<h1>login to ekart</h1>
<c:if test="${not empty error}">
       <p style="color: red;"><c:out value="${error}" /></p>
   </c:if>

<form action="<c:url value='/login' />" method="post">
       <p>Username: <input type="text" name="username" value="" required /></p>
       <p>Password: <input type="password" name="password" required /></p>
       <p><input type="checkbox" name="rememberMe" /> Remember me</p>
       <p><input type="submit" value="Login" /></p>
   </form>

</body>
</html>