<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<jsp:include page="/common/header.jsp"></jsp:include>
<h1>Admin Panel</h1>
   <c:if test="${not empty error}">
       <p style="color: red;"><c:out value="${error}" /></p>
   </c:if>
   <h2>Add New Product</h2>
   <form action="<c:url value='/admin/add-product' />" method="post">
       <p>Name: <input type="text" name="name" required /></p>
       <p>Category: <input type="text" name="category" required /></p>
       <p>Price: <input type="text" name="price" required /></p>
       <p>Stock: <input type="text" name="stock" required /></p>
       <p><input type="submit" value="Add Product" /></p>
   </form>

<h2>Current Products</h2>
   <c:if test="${empty products}">
       <p>No products available.</p>
   </c:if>
   <c:if test="${not empty products}">
       <table border="1" cellpadding="6">
           <tr>
               <th>ID</th>
               <th>Name</th>
               <th>Category</th>
               <th>Price</th>
               <th>Stock</th>
               <th></th>
           </tr>
           <c:forEach items="${products}" var="product">
               <tr>
                   <td><c:out value="${product.id}" /></td>
                   <td><c:out value="${product.name}" /></td>
                   <td><c:out value="${product.category}" /></td>
                   <td><c:out value="${product.price}" /></td>
                   <td><c:out value="${product.stock}" /></td>
                   <td>
                       <form action="<c:url value='/admin/delete-product' />" method="post">
                           <input type="hidden" name="productId" value="${product.id}" />
                           <input type="submit" value="Delete" />
                       </form>
                   </td>
               </tr>
           </c:forEach>
       </table>
   </c:if>


</body>
</html>