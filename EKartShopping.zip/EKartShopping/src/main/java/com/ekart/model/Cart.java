package com.ekart.model;
import java.util.ArrayList;
import java.util.List;
public class Cart {
   private final List<CartItem> items = new ArrayList<>();
   public void add(Product product, int quantity) {
       for (CartItem item : items) {
           if (item.getProduct().getId() == product.getId()) {
               item.setQuantity(item.getQuantity() + quantity);
               return;
           }
       }
       items.add(new CartItem(product, quantity));
   }
   public void remove(int productId) {
       items.removeIf(item -> item.getProduct().getId() == productId);
   }
   public List<CartItem> getItems() {
       return items;
   }
   public int getTotalQuantity() {
       int total = 0;
       for (CartItem item : items) {
           total += item.getQuantity();
       }
       return total;
   }
   public double getTotalPrice() {
       double total = 0.0;
       for (CartItem item : items) {
           total += item.getSubtotal();
       }
       return total;
   }
   public boolean isEmpty() {
       return items.isEmpty();
   }
   public void clear() {
       items.clear();
   }
}