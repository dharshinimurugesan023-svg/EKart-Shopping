package com.ekart.model;

import java.util.List;

public class Order {
	private User user;
	   private List<CartItem> items;
	   private double total;
	   public User getUser() {
		   return user;
	   }
	   public void setUser(User user) {
		   this.user = user;
	   }
	   public List<CartItem> getItems() {
		   return items;
	   }
	   public void setItems(List<CartItem> items) {
		   this.items = items;
	   }
	   public double getTotal() {
		   return total;
	   }
	   public void setTotal(double total) {
		   this.total = total;
	   }
	   public Order(User user, List<CartItem> items, double total) {
		super();
		this.user = user;
		this.items = items;
		this.total = total;
	   }
public Order(){}

}
