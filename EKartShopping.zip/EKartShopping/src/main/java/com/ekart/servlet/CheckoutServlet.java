package com.ekart.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ekart.model.Cart;
import com.ekart.model.CartItem;
import com.ekart.model.Order;
import com.ekart.model.User;

@WebServlet(
        name = "CheckoutServlet",
        urlPatterns = { "/checkout" }
)
public class CheckoutServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Cart cart = null;
        if (session != null) {
            cart = (Cart) session.getAttribute("cart");
        }
        if (cart == null) {
            cart = new Cart();
        }

        request.setAttribute("cart", cart);
        request.getRequestDispatcher("/checkout.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(true);
        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null || cart.isEmpty()) {
            request.setAttribute("error", "Your cart is empty.");
            request.getRequestDispatcher("/checkout.jsp").forward(request, response);
            return;
        }

        User user = (User) session.getAttribute("loggedInUser");

        Order order = new Order(user, new ArrayList<>(cart.getItems()), cart.getTotalPrice());

        cart.clear();
        session.setAttribute("lastOrder", order);

        response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/order-confirm"));
    }
}
