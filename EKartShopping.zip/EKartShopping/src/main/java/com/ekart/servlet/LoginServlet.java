package com.ekart.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ekart.model.User;
import com.ekart.store.UserStore;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/login.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
	       String password = request.getParameter("password");
	       String rememberMe = request.getParameter("rememberMe");
	       User user = authenticate(username, password);
	       if (user == null) {
	           request.setAttribute("error", "Invalid username or password.");
	           request.getRequestDispatcher("/login.jsp").forward(request, response);
	           return;
	       }
	       HttpSession session = request.getSession(true);
	       session.setAttribute("loggedInUser", user);
	       session.setMaxInactiveInterval(30 * 60);
	       response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/products"));

	}


private User authenticate(String username, String password) {
       if (username == null || password == null) {
           return null;
       }
       String adminUsername = getServletContext().getInitParameter("adminUsername");
       String adminPassword = getServletContext().getInitParameter("adminPassword");
       if (adminUsername != null && adminUsername.equals(username)
               && adminPassword != null && adminPassword.equals(password)) {
           return new User(username, password, "Administrator", "ADMIN");
       }

              User user = UserStore.findByUsername(username);
       if (user != null && user.getPassword().equals(password)) {
           return user;
       }
       return null;
   }

}
