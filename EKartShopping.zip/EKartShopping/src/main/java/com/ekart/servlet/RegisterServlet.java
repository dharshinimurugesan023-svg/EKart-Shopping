package com.ekart.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ekart.model.User;
import com.ekart.store.UserStore;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/register.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
	       String password = request.getParameter("password");
	       String name = request.getParameter("name");
	       
	       if (UserStore.exists(username)) {
	           request.setAttribute("error", "Username already taken.");
	           request.getRequestDispatcher("/register.jsp").forward(request, response);
	           return;
	       }
	       User user = new User(username.trim(), password, name.trim(), "USER");
	       UserStore.add(user);
	       request.getSession(true).setAttribute("loggedInUser", user);
	       response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/products"));

	}

}
