package com.ekart.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ekart.model.Order;

@WebServlet(
        name = "OrderConfirmServlet",
        urlPatterns = { "/order-confirm" }
)
public class OrderConfirmServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Order order = null;
        if (session != null) {
            order = (Order) session.getAttribute("lastOrder");
        }

        request.setAttribute("order", order);
        request.getRequestDispatcher("/order-confirm.jsp").forward(request, response);
    }
}
