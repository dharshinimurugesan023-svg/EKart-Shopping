package com.ekart.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ekart.model.Cart;
import com.ekart.model.Product;
import com.ekart.store.ProductStore;

/**
 * Servlet implementation class AddtoCartServlet
 */
@WebServlet("/add-to-cart")
public class AddtoCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddtoCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productId = Integer.parseInt(request.getParameter("productId"));
	       Product product = ProductStore.findById(productId);
	       if (product != null) {
	           HttpSession session = request.getSession(true);
	           Cart cart = (Cart) session.getAttribute("cart");
	           if (cart == null) {
	               cart = new Cart();
	               session.setAttribute("cart", cart);
	           }
	           cart.add(product, 1);
	       }
	       response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/cart"));

	}

}
