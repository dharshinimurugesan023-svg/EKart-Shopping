package com.ekart.servlet;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ekart.model.Product;
import com.ekart.store.ProductStore;

@WebServlet(
        name = "AdminAddProductServlet",
        urlPatterns = { "/admin/add-product" }
)
public class AdminAddProductServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String category = request.getParameter("category");
        String priceParam = request.getParameter("price");
        String stockParam = request.getParameter("stock");

        if (name == null || name.trim().isEmpty()
                || category == null || category.trim().isEmpty()
                || priceParam == null || stockParam == null) {
            request.setAttribute("error", "All fields are required.");
            request.getRequestDispatcher("/admin").forward(request, response);
            return;
        }

        try {
            double price = Double.parseDouble(priceParam);
            int stock = Integer.parseInt(stockParam);

            Product product = new Product(ProductStore.nextId(), name.trim(), price, category.trim(), stock);
            ProductStore.add(product);
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Price and stock must be numbers.");
            request.getRequestDispatcher("/admin").forward(request, response);
            return;
        }

        response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/admin"));
    }
}
