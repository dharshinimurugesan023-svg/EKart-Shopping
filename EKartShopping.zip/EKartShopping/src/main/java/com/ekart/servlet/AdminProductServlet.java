package com.ekart.servlet;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ekart.model.Product;
import com.ekart.store.ProductStore;
@WebServlet(
       name = "AdminProductServlet",
       urlPatterns = { "/admin" }
)
public class AdminProductServlet extends HttpServlet {
   @Override
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
       List<Product> products = ProductStore.getAll();
       request.setAttribute("products", products);
       request.getRequestDispatcher("/admin.jsp").forward(request, response);
   }
}
