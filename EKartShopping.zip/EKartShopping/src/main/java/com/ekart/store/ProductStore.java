package com.ekart.store;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.ekart.model.Product;

public class ProductStore {
	private static final List<Product> products = new ArrayList<>();

    static {
        products.add(new Product(1, "Wireless Mouse", 499.0, "Electronics", 50));
        products.add(new Product(2, "Mechanical Keyboard", 1499.0, "Electronics", 30));
        products.add(new Product(3, "USB-C Charger", 699.0, "Accessories", 100));
        products.add(new Product(4, "Bluetooth Headphones", 2999.0, "Electronics", 25));
        products.add(new Product(5, "Laptop Stand", 899.0, "Accessories", 40));
        products.add(new Product(6, "Webcam 1080p", 1999.0, "Electronics", 20));
        products.add(new Product(7, "Notebook Pack", 199.0, "Stationery", 200));
        products.add(new Product(8, "Desk Lamp", 1299.0, "Accessories", 35));
    }

    public static List<Product> getAll() {
        return Collections.unmodifiableList(products);
    }

    public static Product findById(int id) {
        for (Product p : products) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }
    public static void add(Product product) {
        products.add(product);
    }
    public static boolean deleteById(int id) {
        return products.removeIf(p -> p.getId() == id);
    }
    public static int nextId() {
        int max = 0;
        for (Product p : products) {
            if (p.getId() > max) {
                max = p.getId();
            }
        }
        return max + 1;
    }

}
