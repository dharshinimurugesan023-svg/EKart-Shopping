package com.ekart.store;

import java.util.HashMap;
import java.util.Map;

import com.ekart.model.User;

public class UserStore {
	private static final Map<String, User> users = new HashMap<>();
	   static {
	       users.put("demo", new User("demo", "demo123", "Demo User", "USER"));
	   }
	   public static User findByUsername(String username) {
	       return users.get(username);
	   }
	   public static void add(User user) {
	       users.put(user.getUsername(), user);
	   }
	   public static boolean exists(String username) {
	       return users.containsKey(username);
	   }


}
