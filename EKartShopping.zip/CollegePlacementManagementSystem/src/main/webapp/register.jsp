<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>Student Registration</title>

<style>

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #667eea, #764ba2);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

.container {
    width: 400px;
    background: white;
    padding: 40px;
    border-radius: 18px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
}

h1 {
    text-align: center;
    color: #333;
}

h2 {
    text-align: center;
    color: #667eea;
}

input {
    width: 100%;
    padding: 13px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-sizing: border-box;
}

button {
    width: 100%;
    padding: 14px;
    margin-top: 15px;
    border: none;
    border-radius: 8px;
    background: #667eea;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #5568d8;
}

.login-link {
    text-align: center;
    margin-top: 20px;
}

.login-link a {
    color: #667eea;
    text-decoration: none;
    font-weight: bold;
}

.error {
    text-align: center;
    color: red;
    margin-bottom: 15px;
}

</style>

</head>

<body>

<div class="container">

    <h1>College Placement</h1>

    <h2>Create Account</h2>

    <%
        String error = request.getParameter("error");

        if ("exists".equals(error)) {
    %>

        <div class="error">
            Username already exists!
        </div>

    <%
        } else if ("empty".equals(error)) {
    %>

        <div class="error">
            Please enter username and password.
        </div>

    <%
        }
    %>

    <form action="RegisterServlet" method="post">

        <input type="text"
               name="username"
               placeholder="Create Username"
               required>

        <input type="password"
               name="password"
               placeholder="Create Password"
               required>

        <button type="submit">
            Register
        </button>

    </form>

    <div class="login-link">

        Already have an account?

        <a href="placement.jsp">
            Login Here
        </a>

    </div>

</div>

</body>

</html>