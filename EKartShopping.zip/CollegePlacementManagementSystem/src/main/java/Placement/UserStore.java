package Placement;

import java.util.ArrayList;
import java.util.List;

public class UserStore {

    private static List<User> users = new ArrayList<User>();

    public static boolean registerUser(String username, String password) {

        for (User user : users) {

            if (user.getUsername().equals(username)) {
                return false;
            }
        }

        users.add(new User(username, password));
        return true;
    }

    public static boolean validateUser(String username, String password) {

        for (User user : users) {

            if (user.getUsername().equals(username)
                    && user.getPassword().equals(password)) {

                return true;
            }
        }

        return false;
    }
}