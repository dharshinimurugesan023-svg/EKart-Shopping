package Placement;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || password == null
                || username.trim().isEmpty()
                || password.trim().isEmpty()) {

            response.sendRedirect("placement.jsp?error=empty");
            return;
        }

        username = username.trim();

        boolean valid =
                UserStore.validateUser(username, password);

        if (valid) {

            HttpSession session = request.getSession();

            session.setAttribute("isuserlogged", true);
            session.setAttribute("username", username);

            response.sendRedirect("process.jsp");

        } else {

            response.sendRedirect("placement.jsp?error=invalid");
        }
    }
}