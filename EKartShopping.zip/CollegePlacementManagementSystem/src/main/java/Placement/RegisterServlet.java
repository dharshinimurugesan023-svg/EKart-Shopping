package Placement;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || password == null
                || username.trim().isEmpty()
                || password.trim().isEmpty()) {

            response.sendRedirect("register.jsp?error=empty");
            return;
        }

        username = username.trim();

        boolean registered =
                UserStore.registerUser(username, password);

        if (registered) {

            response.sendRedirect("placement.jsp?registered=true");

        } else {

            response.sendRedirect("register.jsp?error=exists");
        }
    }
}